﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using System.Linq;
using System;
using AutoMapper;
using System.Collections.Generic;
using NetCoreAspGenericControllers.Core;
using Microsoft.AspNetCore.Http;
using System.Net;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TEntity, TViewModel>
        where TEntity : class, IEntityBase, new()
        where TViewModel : class, IViewModel, new()
    {
        private readonly IEntityBaseRepository<TEntity> _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(IEntityBaseRepository<TEntity> repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var pagination = Request.Headers["pagination"];

            if (!string.IsNullOrEmpty(pagination))
            {
                string[] vals = pagination.ToString().Split(',');
                int.TryParse(vals[0], out _page);
                int.TryParse(vals[1], out _pageSize);
            }

            int currentPage = _page;
            int currentPageSize = _pageSize;
            var totalEntities = _repository.Count();
            var totalPages = (int)Math.Ceiling((double)totalEntities / _pageSize);

//IEnumerable<TEntity> _entities = _repository
//    .GetAll()
// TODO: Custom Override 
//.AllIncluding(u => u.SchedulesCreated) < not generic this method must be overrided
//    .OrderBy(u => u.Id)
//    .Skip((currentPage - 1) * currentPageSize)
//    .Take(currentPageSize)
//    .ToList();

// Call GENERIC Crud virtual method, can be overriden by subclasses if needed extra configuration
IEnumerable<TEntity> entities = GetEntities(currentPage, currentPageSize);

			// Map TEntity to TViewModel with AutoMapper
			IEnumerable<TViewModel> usersVM = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TViewModel>>(entities);

			// add Pagiantion to Response
			Response.AddPagination(_page, _pageSize, totalEntities, totalPages);

            return new OkObjectResult(usersVM);
        }

[HttpGet("{id:int}")]
//[HttpGet("{id:int}", Name = string.Format("{0}{1}", GetType().Name, nameof(Get)))]
		public IActionResult Get(int id)
        {
// TODO: Custom Override 
//TEntity _entity = default(TEntity);// = _repository.GetSingle(u => u.Id == id, u => u.SchedulesCreated);
//TEntity _entity = _repository.GetSingle(u => u.Id == id);

// Call GENERIC Crud virtual method, can be overriden by subclasses if needed extra configuration
TEntity _entity = GetEntity(id);

			if (_entity != null)
            {
                TViewModel _userVM = Mapper.Map<TEntity, TViewModel>(_entity);
                return new OkObjectResult(_userVM);
            }
            else
            {
                return NotFound();
            }
        }

// TODO: Custom Override 
//public IActionResult GetSchedules(int id)
//{
//    throw new NotImplementedException();
//}

        [HttpPost]
        public IActionResult Create([FromBody] TViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

			// TODO: Custom Override 
			//User _newUser = new User { Name = user.Name, Profession = user.Profession, Avatar = user.Avatar };
			//TEntity _newEntity = new TEntity();

			// Call GENERIC Crud virtual method, can be overriden by subclasses if needed extra configuration
			TEntity newEntity = CreateEntity(viewModel);

			_repository.Add(newEntity);
            _repository.Commit();

			viewModel = Mapper.Map<TEntity, TViewModel>(newEntity);

			//CreatedAtRouteResult result = CreatedAtRoute("GetUser", new { controller = "Users", id = viewModel.Id }, viewModel);
			ObjectResult result = new ObjectResult(viewModel);
			result.StatusCode = Convert.ToInt16(HttpStatusCode.Created);
			Response.Headers.Add("Location", string.Format("http://localhost:5000/api/{0}/{1}", GetType().Name.ToLower().Replace("controller", string.Empty), viewModel.Id));

			return result;
        }

        [HttpPut("{id:int}")]
        public IActionResult Put(int id, [FromBody] TViewModel entity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return NotFound();
            }
            else
            {
// TODO: Custom Override 
//_entityDb.Name = entity.Name;
//_entityDb.Profession = entity.Profession;
//_entityDb.Avatar = entity.Avatar;
//_userRepository.Commit();
            }

            entity = Mapper.Map<TEntity, TViewModel>(_entityDb);

            return new NoContentResult();
        }

        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return new NotFoundResult();
            }
            else
            {
// TODO: Custom Override 
//IEnumerable<Attendee> _attendees = _attendeeRepository.FindBy(a => a.UserId == id);
//IEnumerable<Schedule> _schedules = _scheduleRepository.FindBy(s => s.CreatorId == id);

//foreach (var attendee in _attendees)
//{
//    _attendeeRepository.Delete(attendee);
//}

//foreach (var schedule in _schedules)
//{
//    _attendeeRepository.DeleteWhere(a => a.ScheduleId == schedule.Id);
//    _scheduleRepository.Delete(schedule);
//}

                _repository.Delete(_entityDb);

                _repository.Commit();

                return new NoContentResult();
            }
        }

		//Virtual method to be overrided by clients, if required extra configuration
		public virtual IEnumerable<TEntity> GetEntities(int currentPage, int currentPageSize)
		{
			return _repository
				.GetAll()
				.OrderBy(u => u.Id)
				.Skip((currentPage - 1) * currentPageSize)
				.Take(currentPageSize)
				.ToList();
		}

		public virtual TEntity GetEntity(int id)
		{
			return _repository.GetSingle(u => u.Id == id);
		}

		// Require to be Extended by Subclass
		public virtual TEntity CreateEntity(TViewModel viewModel)
		{
			throw new NotImplementedException();
		}

		public virtual bool UpdateEntity(ref TEntity entity)
		{
			throw new NotImplementedException();
		}

		public virtual bool DeleteEntity(int id)
		{
			throw new NotImplementedException();
		}
	}
}
