﻿using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Data;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Repository
{
    public class DroidRepository : EntityBaseRepository<Droid>, IDroidRepository
    {
        public DroidRepository(DomainContext context)
            : base(context)
        { }
    }
}
