﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.ViewModels;
using System.Collections.Generic;
using System.Linq;

namespace NetCoreAspGenericControllers.Controllers
{
	[Route("api/[controller]")]
	public class UserController : GenericCrudController<User, UserViewModel>
	{
		private IEntityBaseRepository<User> _repository;

		public UserController(IEntityBaseRepository<User> repository)
			: base(repository)
		{
			_repository = repository;
		}

		public override IEnumerable<User> GetEntities(int currentPage, int currentPageSize)
		{
			IEnumerable<User> entities = _repository
				.AllIncluding(u => u.SchedulesCreated)
				.OrderBy(u => u.Id)
				.Skip((currentPage - 1) * currentPageSize)
				.Take(currentPageSize)
				.ToList();

			return entities;
		}

		//IEntityBase GetEntity();
		public override User GetEntity(int id)
		{
			User entity = _repository
				.GetSingle(
					u => u.Id == id,
					u => u.SchedulesCreated
				);
			return entity;
		}

		//bool CreateEntity(ref TEntity entity);

		//bool UpdateEntity(ref TEntity entity);

		//bool DeleteEntity(int id);

	}
}
