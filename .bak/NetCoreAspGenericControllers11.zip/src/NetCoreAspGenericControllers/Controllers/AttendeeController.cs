﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class AttendeeController : GenericCrudController<Attendee, IAttendeeRepository>
    {
        public AttendeeController(IAttendeeRepository repository)
            : base(repository)
        {
        }
    }
}
