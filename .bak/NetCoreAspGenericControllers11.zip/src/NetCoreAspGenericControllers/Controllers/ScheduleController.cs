﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class ScheduleController : GenericCrudController<Schedule, IScheduleRepository>
    {
        public ScheduleController(IScheduleRepository repository)
            : base(repository)
        {
        }
    }
}
