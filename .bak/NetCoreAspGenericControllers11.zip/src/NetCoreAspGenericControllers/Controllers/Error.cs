﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Controllers
{
    public class Error
    {
        public int HttpCode { get; set; }
        public string Message { get; set; }
    }
}
