﻿using System;
using System.Collections.Generic;

namespace NetCoreAspGenericControllers.Model
{
    public class Droid : EntityBase
    {
        public Guid ImperialContractId { get; set; }
        public string Name { get; set; }
        public long CreditBalance { get; set; }
        public string ProductSeries { get; set; }

        public decimal Height { get; set; }
        public decimal Weight { get; set; }
        public IEnumerable<string> Armaments { get; set; }
        public IEnumerable<string> Equipment { get; set; }

        // Required Parameterless Constructor
        public Droid() { }

        public Droid(DTO.Droid dtoDroid)
            :base()
        {
            Id = dtoDroid.Id;
            ImperialContractId = dtoDroid.ImperialContractId;
            Name = dtoDroid.Name;
            CreditBalance = dtoDroid.CreditBalance;
            ProductSeries = dtoDroid.ProductSeries;
            Height = dtoDroid.Height;
            Weight = dtoDroid.Weight;
            Armaments = dtoDroid.Armaments;
            Equipment = dtoDroid.Equipment;
        }
    }
}