﻿using DomainModel.Entities;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Abstract
{
    public interface IScheduleRepository : IEntityBaseRepository<Schedule> { }
    public interface IUserRepository : IEntityBaseRepository<User> { }
    public interface IAttendeeRepository : IEntityBaseRepository<Attendee> { }
    public interface IDroidRepository : IEntityBaseRepository<Droid> { }
}
