﻿using NetCoreAspGenericControllers.Data;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;

namespace NetCoreAspGenericControllers.Abstract
{
    public class DroidRepository : EntityBaseRepository<Droid>, IDroidRepository
    {
        public DroidRepository(DomainContext context)
            : base(context)
        { }
    }
}
