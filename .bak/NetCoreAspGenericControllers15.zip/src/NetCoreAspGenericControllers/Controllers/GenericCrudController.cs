﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using System.Linq;
using System;
using AutoMapper;
using System.Collections.Generic;
using NetCoreAspGenericControllers.Core;
using System.ComponentModel.DataAnnotations;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TViewModel : class, IValidatableObject, new()
    {
        private readonly IEntityBaseRepository<TEntity> _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(IEntityBaseRepository<TEntity> repository)
        {
            this._repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var pagination = Request.Headers["Pagination"];

            if (!string.IsNullOrEmpty(pagination))
            {
                string[] vals = pagination.ToString().Split(',');
                int.TryParse(vals[0], out _page);
                int.TryParse(vals[1], out _pageSize);
            }

            int currentPage = _page;
            int currentPageSize = _pageSize;
            var totalUsers = _repository.Count();
            var totalPages = (int)Math.Ceiling((double)totalUsers / _pageSize);

            IEnumerable<TEntity> _entities = _repository
                .GetAll()
                //.AllIncluding(u => u.SchedulesCreated) < not generic this method must be overrided
                .OrderBy(u => u.Id)
                .Skip((currentPage - 1) * currentPageSize)
                .Take(currentPageSize)
                .ToList();

            IEnumerable<TViewModel> _usersVM = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TViewModel>>(_entities);

            Response.AddPagination(_page, _pageSize, totalUsers, totalPages);

            return new OkObjectResult(_usersVM);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            TEntity _entity = default(TEntity);// = _repository.GetSingle(u => u.Id == id, u => u.SchedulesCreated);

            if (_entity != null)
            {
                TViewModel _userVM = Mapper.Map<TEntity, TViewModel>(_entity);
                return new OkObjectResult(_userVM);
            }
            else
            {
                return NotFound();
            }
        }

        //public IActionResult GetSchedules(int id)
        //{
        //    throw new NotImplementedException();
        //}

        [HttpPost]
        public IActionResult Create([FromBody] TViewModel user)
        {
            throw new NotImplementedException();
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] TViewModel user)
        {
            throw new NotImplementedException();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
