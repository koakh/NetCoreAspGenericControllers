﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.ViewModels;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class AttendeeController : GenericCrudController<Attendee, AttendeeViewModel>
    {
        public AttendeeController(IEntityBaseRepository<Attendee> repository)
            : base(repository)
        {
        }
    }
}
