﻿using FluentValidation;

namespace NetCoreAspGenericControllers.ViewModels.Validations
{
    public class AttendeeViewModelValidator : AbstractValidator<AttendeeViewModel>
    {
        public AttendeeViewModelValidator()
        {
        }
    }
}
