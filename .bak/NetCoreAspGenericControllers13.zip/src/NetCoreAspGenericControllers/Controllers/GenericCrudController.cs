﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using System.Linq;
using System;
using AutoMapper;
using System.Collections.Generic;
using NetCoreAspGenericControllers.Core;
using System.ComponentModel.DataAnnotations;

namespace NetCoreAspGenericControllers.Controllers
{
    // E:Entity
    // R:I[Entity]Repository
    // V:[Entity]ViewModel
    [Route("generic-crud-controller")]
    public class GenericCrudController<E, R, V> : Controller, IGenericCrudController<V>
        where E : class, IEntityBase, new()
        where R : class, IEntityBaseRepository<E>, new()
        where V : class, IValidatableObject, new()
    {
        private readonly R _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(R repository)
        {
            this._repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var pagination = Request.Headers["Pagination"];

            if (!string.IsNullOrEmpty(pagination))
            {
                string[] vals = pagination.ToString().Split(',');
                int.TryParse(vals[0], out _page);
                int.TryParse(vals[1], out _pageSize);
            }

            int currentPage = _page;
            int currentPageSize = _pageSize;
            var totalUsers = _repository.Count();
            var totalPages = (int)Math.Ceiling((double)totalUsers / _pageSize);

            IEnumerable<E> _entities = _repository
                .GetAll()
                //.AllIncluding(u => u.SchedulesCreated)
                .OrderBy(u => u.Id)
                .Skip((currentPage - 1) * currentPageSize)
                .Take(currentPageSize)
                .ToList();

            IEnumerable<V> _usersVM = Mapper.Map<IEnumerable<E>, IEnumerable<V>>(_entities);

            Response.AddPagination(_page, _pageSize, totalUsers, totalPages);

            return new OkObjectResult(_usersVM);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            E _entity = default(E);// = _repository.GetSingle(u => u.Id == id, u => u.SchedulesCreated);

            if (_entity != null)
            {
                V _userVM = Mapper.Map<E, V>(_entity);
                return new OkObjectResult(_userVM);
            }
            else
            {
                return NotFound();
            }
        }

        //public IActionResult GetSchedules(int id)
        //{
        //    throw new NotImplementedException();
        //}

        [HttpPost]
        public IActionResult Create([FromBody] V user)
        {
            throw new NotImplementedException();
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] V user)
        {
            throw new NotImplementedException();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
