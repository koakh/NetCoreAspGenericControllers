﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Controllers
{
    // E:Entity
    // R:IRepository
    [Route("generic-crud-controller")]
    public class GenericCrudController<E, R> : Controller
        where E : IEntityBase
        //where R : IEntityBaseRepository<E>
    {
        readonly R repository;

        public GenericCrudController(R repository)
        {
            this.repository = repository;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            throw new NotImplementedException();
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public IActionResult Create([FromBody] E entity)
        {
            throw new NotImplementedException();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            throw new NotImplementedException();
        }

        [HttpPut]
        public IActionResult Update([FromBody] E entity)
        {
            throw new NotImplementedException();
        }
    }
}
