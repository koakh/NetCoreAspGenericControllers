﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class DroidController : GenericCrudController<Droid, IDroidRepository>
    {
        public const string namedRouteGetById = "DroidGetById";
        public DroidController(IDroidRepository repository) 
            : base(repository)
        {
        }
    }
}
