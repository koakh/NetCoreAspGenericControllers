﻿namespace NetCoreAspGenericControllers.App
{
	public class AppSettings
	{
		public string ApplicationName { get; set; } = "Application Name";
		public string ApiEndPoint { get; set; } = "http://localhost:5000/api";
		public int ApiPageSize { get; set; } = 10;
	}
}
