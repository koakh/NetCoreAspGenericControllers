﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.ViewModels;
using System;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
	public class ScheduleController : GenericCrudController<Schedule, ScheduleViewModel>
    {
        public ScheduleController(IEntityBaseRepository<Schedule> repository)
            : base(repository)
        {
        }

		public override Schedule CreateEntity(ScheduleViewModel viewModel)
		{
			return default(Schedule);
		}

		public override void UpdateEntity(ref Schedule entity, ScheduleViewModel viewModel)
		{
			throw new NotImplementedException();
		}
	}
}
