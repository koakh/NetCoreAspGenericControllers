﻿using NetCoreAspGenericControllers.DTO;
using NetCoreAspGenericControllers.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace NetCoreAspGenericControllers.Repository
{
    public class DroidGenericCrudRepository 
        : IGenericCrudRepository<Droid>
    {
        public IActionResult Create([FromBody] Droid entity)
        {
            throw new NotImplementedException();
        }

        public IActionResult Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IActionResult GetAll()
        {
            throw new NotImplementedException();
        }

        public IActionResult GetById(int id)
        {
            throw new NotImplementedException();
        }

        public IActionResult Update([FromBody] Droid entity)
        {
            throw new NotImplementedException();
        }
    }
}
