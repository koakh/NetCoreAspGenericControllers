﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Repository
{
    public class SeedDroidRepository
    {
        private static int id;

        /// <summary>
        /// Seed the database with a few initial droids
        /// </summary>
        public static void Seed(ConcurrentDictionary<int, Model.Droid> repository)
        {
            var ig88B = new Model.Droid
            {
                Id = id++,
                ImperialContractId = Guid.Parse("0B450FDD-F484-423B-8685-4193E9FA0001"),
                Name = "IG-88B",
                CreditBalance = 4500000,
                ProductSeries = "IG-88",
                Height = 10,
                Weight = 20,
                Armaments = new List<string> {
                    "DAS-430 Neural Inhibitor", "Heavy pulse cannon", "Poison darts",
                    "Toxic gas dispensers", "Vibroblades"
                },
                Equipment = new List<string>()
            };
            repository.TryAdd(ig88B.Id, ig88B);

            var c3po = new Model.Droid
            {
                Id = id++,
                ImperialContractId = Guid.Parse("0B450FDD-F484-423B-8685-4193E9FA0002"),
                Name = "C-3PO",
                ProductSeries = "3PO-series Protocol Droid",
                Height = 1.71M,
                Weight = 20,
                Armaments = new List<string>(),
                Equipment = new List<string>
                {
                    "TranLang III communication module"
                }
            };
            repository.TryAdd(c3po.Id, c3po);

            var r2d2 = new Model.Droid
            {
                Id = id++,
                ImperialContractId = Guid.Parse("0B450FDD-F484-423B-8685-4193E9FA0003"),
                Name = "R2-D2",
                ProductSeries = "R-Series",
                CreditBalance = 100,
                Height = 0.96M,
                Weight = 0.28M,
                Armaments = new List<string> {
                    "Buzz saw", "Electric pike"
                },
                Equipment = new List<string>
                {
                    "Drinks tray (only on sail barge)", "Fusion welder",
                    "Com link", "Power recharge coupler",
                    "Rocket boosters", "Holographic projector/recorder",
                    "Motorized, all-terrain treads", "Retractable third leg",
                    "Periscope", "Fire extinguisher", "Hidden lightsaber compartment with ejector",
                    "Data probe", "Life-form scanner", "Utility arm"
                }
            };
            repository.TryAdd(r2d2.Id, r2d2);

            var bb8 = new Model.Droid
            {
                Id = id++,
                ImperialContractId = Guid.Parse("0B450FDD-F484-423B-8685-4193E9FA0004"),
                Name = "BB-8",
                ProductSeries = "BB Unit",
                Height = 0.67M,
                Weight = 20,
                Armaments = new List<string>(),
                Equipment = new List<string>
                {
                    "Liquid cable launchers",
                    "Welding torch",
                    "Holoprojector",
                    "Arc welder"
                }
            };
            repository.TryAdd(bb8.Id, bb8);

            var k2so = new Model.Droid
            {
                Id = id++,
                Name = "K-2SO",
                ProductSeries = "KX Series Security Droid",
                Height = 2.16M,
                Weight = 20,
                Armaments = new List<string>(),
                Equipment = new List<string>()
            };
            repository.TryAdd(k2so.Id, k2so);
        }
    }
}
