﻿using NetCoreAspGenericControllers.DTO;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace NetCoreAspGenericControllers.Repository
{
    public class DroidRepository : IDroidRepository
    {
        private static int id;

        private static ConcurrentDictionary<int, Model.Droid> repository { get; } = new ConcurrentDictionary<int, Model.Droid>();
        public DroidRepository()
        {
            SeedDroidRepository.Seed(repository);
        }

        public bool Create(Droid newDroid)
        {
            var droid = new Model.Droid(newDroid);
            newDroid.Id = id++;
            repository.TryAdd(newDroid.Id, new Model.Droid(newDroid));
            return true;
        }

        public Droid Delete(int id)
        {
            Model.Droid modelDroid;
            repository.TryRemove(id, out modelDroid);
            return new Droid(modelDroid);
        }

        public Droid Get(int id)
        {
            var droid = repository.Values.FirstOrDefault(d => d.Id == id);
            if (droid != null)
            {
                return new Droid(droid);
            }
            return null;
        }

        public IEnumerable<Droid> GetAll()
        {
            var droids = new List<Droid>();
            foreach (var droid in repository.Values)
            {
                var newDroid = new Droid(droid);
                droids.Add(newDroid);
            }
            return droids.OrderBy(d => d.Id);
        }

        public Droid Update(Droid droid)
        {
            if (repository.ContainsKey(droid.Id))
            {
                droid.Id = repository[droid.Id].Id;
                repository[droid.Id] = new Model.Droid(droid);
                return droid;
            }
            return null;
        }
    }
}