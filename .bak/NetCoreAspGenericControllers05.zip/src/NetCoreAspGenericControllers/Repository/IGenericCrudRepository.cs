﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Repository
{
    interface IGenericCrudRepository<T>
    {
        IActionResult GetAll();
        IActionResult GetById(int id);
        IActionResult Create([FromBody] T entity);
        IActionResult Delete(int id);
        IActionResult Update([FromBody] T entity);
    }
}
