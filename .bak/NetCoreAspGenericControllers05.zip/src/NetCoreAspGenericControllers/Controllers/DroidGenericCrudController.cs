﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class DroidGenericCrudController : GenericCrudController<Droid, DroidGenericCrudRepository>
    {
        public DroidGenericCrudController(DroidGenericCrudRepository repository) 
            : base(repository)
        {
        }
    }
}
