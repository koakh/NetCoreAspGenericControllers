﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;
using NetCoreAspGenericControllers.ViewModels;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class ScheduleController : GenericCrudController<Schedule, ScheduleRepository, ScheduleViewModel>
    {
//public ScheduleController(ScheduleRepository repository)
        public ScheduleController(IEntityBaseRepository<Schedule> repository)
            : base(repository)
        {
        }
    }
}
