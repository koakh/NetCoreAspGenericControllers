﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;
using NetCoreAspGenericControllers.ViewModels;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class AttendeeController : GenericCrudController<Attendee, AttendeeRepository, AttendeeViewModel>
    {
        public AttendeeController(AttendeeRepository repository)
            : base(repository)
        {
        }
    }
}
