﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;
using NetCoreAspGenericControllers.ViewModels;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class UserController : GenericCrudController<User, UserRepository, UserViewModel>
    {
        public UserController(UserRepository repository)
            : base(repository)
        {
        }
    }
}
