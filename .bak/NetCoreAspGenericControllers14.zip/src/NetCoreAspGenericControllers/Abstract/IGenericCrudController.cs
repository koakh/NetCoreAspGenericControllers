﻿using Microsoft.AspNetCore.Mvc;

namespace NetCoreAspGenericControllers.Abstract
{
    //T:[Entity]ViewModel
    interface IGenericCrudController<T>
    {
        IActionResult Get();

        IActionResult Get(int id);

        IActionResult Create([FromBody] T user);

        IActionResult Put(int id, [FromBody] T user);

        IActionResult Delete(int id);
    }
}
