﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<T> : Controller where T : IEntityBase
    {
        [HttpGet]
        public ActionResult Get()
        {
            return new OkResult();
        }
    }
}