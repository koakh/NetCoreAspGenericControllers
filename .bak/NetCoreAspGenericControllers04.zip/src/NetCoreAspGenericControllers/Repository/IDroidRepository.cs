﻿using NetCoreAspGenericControllers.DTO;
using System.Collections.Generic;

namespace NetCoreAspGenericControllers.Repository
{
    public interface IDroidRepository
    {
        IEnumerable<Droid> GetAll();
        bool Create(Droid newDroid);
        Droid Get(int id);
        Droid Update(Droid droid);
        Droid Delete(int id);
    }
}
