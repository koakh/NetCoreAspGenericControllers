﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using System.Linq;
using System;
using AutoMapper;
using System.Collections.Generic;
using NetCoreAspGenericControllers.Core;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TViewModel : class, IViewModel, new()
    {
        private readonly IEntityBaseRepository<TEntity> _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(IEntityBaseRepository<TEntity> repository)
        {
            this._repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var pagination = Request.Headers["Pagination"];

            if (!string.IsNullOrEmpty(pagination))
            {
                string[] vals = pagination.ToString().Split(',');
                int.TryParse(vals[0], out _page);
                int.TryParse(vals[1], out _pageSize);
            }

            int currentPage = _page;
            int currentPageSize = _pageSize;
            var totalUsers = _repository.Count();
            var totalPages = (int)Math.Ceiling((double)totalUsers / _pageSize);

            IEnumerable<TEntity> _entities = _repository
                .GetAll()
// TODO: Custom Override 
//.AllIncluding(u => u.SchedulesCreated) < not generic this method must be overrided
                .OrderBy(u => u.Id)
                .Skip((currentPage - 1) * currentPageSize)
                .Take(currentPageSize)
                .ToList();

            IEnumerable<TViewModel> _usersVM = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TViewModel>>(_entities);

            Response.AddPagination(_page, _pageSize, totalUsers, totalPages);

            return new OkObjectResult(_usersVM);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
// TODO: Custom Override 
//TEntity _entity = default(TEntity);// = _repository.GetSingle(u => u.Id == id, u => u.SchedulesCreated);
            TEntity _entity = _repository.GetSingle(u => u.Id == id);

            if (_entity != null)
            {
                TViewModel _userVM = Mapper.Map<TEntity, TViewModel>(_entity);
                return new OkObjectResult(_userVM);
            }
            else
            {
                return NotFound();
            }
        }

// TODO: Custom Override 
//public IActionResult GetSchedules(int id)
//{
//    throw new NotImplementedException();
//}

        [HttpPost]
        public IActionResult Create([FromBody] TViewModel entity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
// TODO: Custom Override 
//User _newUser = new User { Name = user.Name, Profession = user.Profession, Avatar = user.Avatar };
            TEntity _newEntity = new TEntity();

            _repository.Add(_newEntity);
            _repository.Commit();

            entity = Mapper.Map<TEntity, TViewModel>(_newEntity);

            CreatedAtRouteResult result = CreatedAtRoute("GetUser", new { controller = "Users", id = entity.Id }, entity);

            return result;
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] TViewModel entity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return NotFound();
            }
            else
            {
// TODO: Custom Override 
//_entityDb.Name = entity.Name;
//_entityDb.Profession = entity.Profession;
//_entityDb.Avatar = entity.Avatar;
//_userRepository.Commit();
            }

            entity = Mapper.Map<TEntity, TViewModel>(_entityDb);

            return new NoContentResult();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return new NotFoundResult();
            }
            else
            {
// TODO: Custom Override 
//IEnumerable<Attendee> _attendees = _attendeeRepository.FindBy(a => a.UserId == id);
//IEnumerable<Schedule> _schedules = _scheduleRepository.FindBy(s => s.CreatorId == id);

//foreach (var attendee in _attendees)
//{
//    _attendeeRepository.Delete(attendee);
//}

//foreach (var schedule in _schedules)
//{
//    _attendeeRepository.DeleteWhere(a => a.ScheduleId == schedule.Id);
//    _scheduleRepository.Delete(schedule);
//}

                _repository.Delete(_entityDb);

                _repository.Commit();

                return new NoContentResult();
            }
        }
    }
}
