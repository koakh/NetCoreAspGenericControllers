﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using System.Linq;
using System;
using AutoMapper;
using System.Collections.Generic;
using NetCoreAspGenericControllers.Core;
using System.Net;
using Microsoft.Extensions.Configuration;

namespace NetCoreAspGenericControllers.Controllers
{
	[Route("generic-crud-controller")]
    public abstract class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TEntity, TViewModel>
        where TEntity : class, IEntityBase, new()
        where TViewModel : class, IViewModel, new()
    {
        private readonly IEntityBaseRepository<TEntity> _repository;
		public IConfigurationRoot _configuration;

		private int _page = 1;
        private int _pageSize = 10;

		public GenericCrudController(IEntityBaseRepository<TEntity> repository)
		{
			_repository = repository;
		}

		[HttpGet]
        public IActionResult Get()
        {
            var pagination = Request.Headers["pagination"];

            if (!string.IsNullOrEmpty(pagination))
            {
                string[] vals = pagination.ToString().Split(',');
                int.TryParse(vals[0], out _page);
                int.TryParse(vals[1], out _pageSize);
            }

            int currentPage = _page;
            int currentPageSize = _pageSize;
            var totalEntities = _repository.Count();
            var totalPages = (int)Math.Ceiling((double)totalEntities / _pageSize);

			// Call GENERIC Crud virtual method, can be overriden by subclasses if needed extra configuration
			IEnumerable<TEntity> entities = GetEntities(currentPage, currentPageSize);

			// Map TEntity to TViewModel with AutoMapper
			IEnumerable<TViewModel> usersVM = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TViewModel>>(entities);

			// add Pagiantion to Response
			Response.AddPagination(_page, _pageSize, totalEntities, totalPages);

            return new OkObjectResult(usersVM);
        }

		[HttpGet("{id:int}")]
		public IActionResult Get(int id)
        {
			// Call GENERIC Crud virtual method, can be overriden by subclasses if needed extra configuration
			TEntity _entity = GetEntity(id);

			if (_entity != null)
            {
                TViewModel _userVM = Mapper.Map<TEntity, TViewModel>(_entity);
                return new OkObjectResult(_userVM);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public IActionResult Create([FromBody] TViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

			// Call GENERIC Crud virtual method, can be overriden by subclasses if needed extra configuration
			TEntity newEntity = CreateEntity(viewModel);

			//Add Entity to Repository
			_repository.Add(newEntity);
			//Repository Commit
			_repository.Commit();

			//AutoMapper Map ViewModel
			viewModel = Mapper.Map<TEntity, TViewModel>(newEntity);

			//CreatedAtRouteResult result = CreatedAtRoute("GetUser", new { controller = "Users", id = viewModel.Id }, viewModel);
			ObjectResult result = new ObjectResult(viewModel);
			result.StatusCode = Convert.ToInt16(HttpStatusCode.Created);
//Todo
//string endPoint = _configuration["Api:EndPoint"];
			Response.Headers.Add("Location", string.Format("{0}/{1}/{2}", "http://localhost:5000/api", GetType().Name.ToLower().Replace("controller", string.Empty), viewModel.Id));

			return result;
        }

        [HttpPut("{id:int}")]
        public IActionResult Put(int id, [FromBody] TViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return NotFound();
            }
            else
            {
// TODO: Custom Override 
//_entityDb.Name = entity.Name;
//_entityDb.Profession = entity.Profession;
//_entityDb.Avatar = entity.Avatar;

//Call GENERIC Crud abstract method, MUST be overriden by subclass
UpdateEntity(ref _entityDb, viewModel);
//Repository Commit
_repository.Commit();
            }

            viewModel = Mapper.Map<TEntity, TViewModel>(_entityDb);

            return new NoContentResult();
        }

        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return new NotFoundResult();
            }
            else
            {
// TODO: Custom Override 
//IEnumerable<Attendee> _attendees = _attendeeRepository.FindBy(a => a.UserId == id);
//IEnumerable<Schedule> _schedules = _scheduleRepository.FindBy(s => s.CreatorId == id);

//foreach (var attendee in _attendees)
//{
//    _attendeeRepository.Delete(attendee);
//}

//foreach (var schedule in _schedules)
//{
//    _attendeeRepository.DeleteWhere(a => a.ScheduleId == schedule.Id);
//    _scheduleRepository.Delete(schedule);
//}

// Call Subclass DeleteEntity
DeleteEntity(id);

				// Always Delete Generic Entity after custom DeleteEntity subclass method, if implemented
				_repository.Delete(_entityDb);
				//Repository Commit
				_repository.Commit();

                return new NoContentResult();
            }
        }

		//Virtual method to be overrided by clients, if required extra configuration
		[ApiExplorerSettings(IgnoreApi = true)]
		public virtual IEnumerable<TEntity> GetEntities(int currentPage, int currentPageSize)
		{
			return _repository
				.GetAll()
				.OrderBy(u => u.Id)
				.Skip((currentPage - 1) * currentPageSize)
				.Take(currentPageSize)
				.ToList();
		}

		//Virtual method to be overrided by clients, if required extra configuration
		[ApiExplorerSettings(IgnoreApi = true)]
		public virtual TEntity GetEntity(int id)
		{
			return _repository.GetSingle(u => u.Id == id);
		}

		// Abstract Method : Must be implemented by Subclass
		[ApiExplorerSettings(IgnoreApi = true)]
		public abstract TEntity CreateEntity(TViewModel viewModel);

		// Abstract Method : Must be implemented by Subclass
		[ApiExplorerSettings(IgnoreApi = true)]
		public abstract void UpdateEntity(ref TEntity entity, TViewModel viewModel);

		//Virtual method to be overrided by clients, if required extra configuration
		[ApiExplorerSettings(IgnoreApi = true)]
		public virtual void DeleteEntity(int id)
		{
		}
	}
}
