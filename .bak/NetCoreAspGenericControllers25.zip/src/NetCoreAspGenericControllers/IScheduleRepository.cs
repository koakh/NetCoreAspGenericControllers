﻿namespace NetCoreAspGenericControllers.Controllers
{
    public interface IScheduleRepository<T>
    {
    }
}