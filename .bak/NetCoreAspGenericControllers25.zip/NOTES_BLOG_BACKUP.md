#### ASP.NET Core : Generic Controllers

**Endpoints**

- http://localhost:5000/api/orders
- http://localhost:5000/api/simpleorder
- http://localhost:5000/api/droids


- [Discovering Generic Controllers in ASP.NET Core](http://stackoverflow.com/questions/36680933/discovering-generic-controllers-in-asp-net-core)
- [AspNetCoreCustomControllerNames](https://github.com/bigfont/StackOverflow/tree/937b13d1a720b9bc4d1dd3662d09cde8ee8b3c89/AspNetCoreCustomControllerNames)

Must Implement [IApplicationFeatureProvider<ControllerFeature>](https://github.com/aspnet/Mvc/blob/0d0aad41f501243f250b77613c015b4267e8c78d/src/Microsoft.AspNetCore.Mvc.Core/Controllers/ControllerFeatureProvider.cs#L15)

1. Create ASP.NET Core Web Application (.NET Core) > WebApi

2. Copy MyControllerFeatureProvider.cs, OrdersFoobar.cs and OrdersFoobarGeneric.cs to NetCoreAspGenericControllers\Controllers, and Change namespace to namespace  ```NetCoreAspGenericControllers.Controllers```

3. Add **FeatureProviders** to Startup ConfigureServices

```
public void ConfigureServices(IServiceCollection services)
{
    // Add MVC with ControllerFeatureProvider
    services.AddMvc().ConfigureApplicationPartManager(manager =>
    {
        manager.FeatureProviders.Add(new MyControllerFeatureProvider());
    });
}
```

4. Change MyControllerFeatureProvider.cs adding ```if (isController)```

```
if (isController)
{
    // Output Detected Controllers
    Console.WriteLine(\$"{typeInfo.Name} IsController: {isController}.");
}
```

Output

```
OrdersFoobar IsController: True.
OrdersFoobarController`1 IsController: True.
ValuesController IsController: True.
```

**Run and test with**

http://localhost:5000/Orders

change OrdersFoobar.cs route 

from

```
[Route("orders")]
```

to

```
[Route("api/[orders]")]
```

**test gives error**

`` 
Error: While processing template 'api/[orders]', a replacement value for the token 'orders' could not be found. Available tokens: 'action, controller'.
`` 

must be 

`` 
[Route("api/orders")]
`` 

> without [] in orders to be replaced

----
#### Create a generic controller child using SimpleOrder

```
public class SimpleOrder : IOrder { }
```

```
using Microsoft.AspNetCore.Mvc;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/simpleorder")]
    public class OrdersFoobarChild : OrdersFoobarController<SimpleOrder>
    {
    }
}
```

----
#### Add Droid Repository

Add files, and change namespaces

```
Controllers\DroidsController.cs
DTO\Droid.cs
Droid.cs
DroidRepository.cs
IDroidRepository.cs
Repository\SeedDroidRepository.cs
```

Use Droid DTO in Controller and DroidsController, IDroidRepository, change it to DroidDTO.cs

run, now it appears on **ControllerFeatureProvider**

```
info: Microsoft.AspNetCore.Hosting.Internal.WebHost[1] 
      Request starting HTTP/1.1 GET http://localhost:5000/api/droids
DroidsController IsController: True.
OrdersFoobar IsController: True.
OrdersFoobarChild IsController: True.
OrdersFoobarController`1 IsController: True.
ValuesController IsController: True.
fail: Microsoft.AspNetCore.Server.Kestrel[13]
      Connection id "0HL2R6REB26E9": An unhandled exception was thrown by the application.
System.InvalidOperationException: Unable to resolve service for type 'NetCoreAspGenericControllers.Repository.IDroidRepository' while attempting to activate 'NetCoreAspGenericControllers.Controllers.DroidsController'.
   at Microsoft.Extensions.Internal.ActivatorUtilities.GetService(IServiceProvider sp, Type type, Type requiredBy, Boolean isDefaultParameterRequired)
```

The error is derivated of forget to Droid Service Repository in Startup

```
public void ConfigureServices(IServiceCollection services)
{
    ...
    //Add IDroidRepository to DI Service Container
    services.AddSingleton<IDroidRepository, DroidRepository>();
}
```

----
#### Start to add Database and DomainContext to create a Generic Repository

**Add Entities to Model\**

```
Model\Attendee.cs
Model\EntityBase.cs
Model\IEntityBase.cs
Model\Schedule.cs
Model\User.cs
```

**Add localdb connectionString**

```
{
    "ConnectionStrings": {
        "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=aspnet-WebApplication-fc1edc2e-8ebf-4398-a70e-6f207fe6df95;Trusted_Connection=True;MultipleActiveResultSets=true"
    },
```

**ConfigureServices Context, Configure and ContextInitializer**

```
public void ConfigureServices(IServiceCollection services)
{
    // Add framework services.
    services.AddApplicationInsightsTelemetry(Configuration);

    // Add database Context
    services.AddDbContext<DomainContext>(options =>
        options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"))
    );
    ...    
    
public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
{
    ...
    app.UseMvc();

    // Get Service and Ensure Database is Created before Initialize Context
    var serviceDomainContext = app.ApplicationServices.GetRequiredService<DomainContext>();
    serviceDomainContext.Database.EnsureCreated();
    DomainContextInitializer.Initialize(app.ApplicationServices);
}
```

**add Data\DomainContext.cs**

```
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using NetCoreAspGenericControllers.Model;
using DomainModel.Entities;
using NetCoreAspGenericControllers.Abstract;

namespace NetCoreAspGenericControllers.Data
{
    public class DomainContext : DbContext
    {
        public virtual DbSet<Attendee> Attendee { get; set; }
        public virtual DbSet<Schedule> Schedule { get; set; }
        public virtual DbSet<User> User { get; set; }

        public DomainContext(DbContextOptions options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            foreach (var relationship in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }

            modelBuilder.Entity<Schedule>()
                .ToTable("DemoSchedule");

            modelBuilder.Entity<Schedule>()
                .Property(s => s.CreatorId)
                .IsRequired();

            modelBuilder.Entity<Schedule>()
                .Property(s => s.DateCreated)
                .HasDefaultValue(DateTime.Now);

            modelBuilder.Entity<Schedule>()
                .Property(s => s.DateUpdated)
                .HasDefaultValue(DateTime.Now);

            modelBuilder.Entity<Schedule>()
                .Property(s => s.Type)
                .HasDefaultValue(ScheduleType.Work);

            modelBuilder.Entity<Schedule>()
                .Property(s => s.Status)
                .HasDefaultValue(ScheduleStatus.Valid);

            modelBuilder.Entity<Schedule>()
                .HasOne(s => s.Creator)
                .WithMany(c => c.SchedulesCreated);

            modelBuilder.Entity<User>()
              .ToTable("DemoUser");

            modelBuilder.Entity<User>()
                .Property(u => u.Name)
                .HasMaxLength(100)
                .IsRequired();

            modelBuilder.Entity<Attendee>()
              .ToTable("DemoAttendee");

            modelBuilder.Entity<Attendee>()
                .HasOne(a => a.User)
                .WithMany(u => u.SchedulesAttended)
                .HasForeignKey(a => a.UserId);

            modelBuilder.Entity<Attendee>()
                .HasOne(a => a.Schedule)
                .WithMany(s => s.Attendees)
                .HasForeignKey(a => a.ScheduleId);
        }
    }
}
```

**Add Data\DomainContextInitializer.cs**

```
using DomainModel.Entities;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NetCoreAspGenericControllers.Data
{
    public class DomainContextInitializer
    {
        private static DomainContext context;
        public static void Initialize(IServiceProvider serviceProvider)
        {
            context = (DomainContext)serviceProvider.GetService(typeof(DomainContext));

            InitializeSchedules();
        }

        private static void InitializeSchedules()
        {
            if(!context.User.Any())
            {
                User user_01 = new User { Name = "Chris Sakellarios", Profession = "Developer", Avatar = "avatar_02.png" };
                User user_02 = new User { Name = "Charlene Campbell", Profession = "Web Designer", Avatar = "avatar_03.jpg" };
                User user_03 = new User { Name = "Mattie Lyons", Profession = "Engineer", Avatar = "avatar_05.png" };
                User user_04 = new User { Name = "Kelly Alvarez", Profession = "Network Engineer", Avatar = "avatar_01.png" };
                User user_05 = new User { Name = "Charlie Cox", Profession = "Developer", Avatar = "avatar_03.jpg" };
                User user_06 = new User { Name = "Megan	Fox", Profession = "Hacker", Avatar = "avatar_05.png" };

                context.User.Add(user_01); context.User.Add(user_02);
                context.User.Add(user_03); context.User.Add(user_04);
                context.User.Add(user_05); context.User.Add(user_06);

                context.SaveChanges();
            }

            if(!context.Schedule.Any())
            {
                Schedule schedule_01 = new Schedule
                {
                    Title = "Meeting",
                    Description = "Meeting at work with the boss",
                    Location = "Korai",
                    CreatorId = 1,
                    Status = ScheduleStatus.Valid,
                    Type = ScheduleType.Work,
                    TimeStart = DateTime.Now.AddHours(4),
                    TimeEnd = DateTime.Now.AddHours(6),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 1, UserId = 2 },
                        new Attendee() { ScheduleId = 1, UserId = 3 },
                        new Attendee() { ScheduleId = 1, UserId = 4 }
                    }                    
                };

                Schedule schedule_02 = new Schedule
                {
                    Title = "Coffee",
                    Description = "Coffee with folks",
                    Location = "Athens",
                    CreatorId = 2,
                    Status = ScheduleStatus.Valid,
                    Type = ScheduleType.Coffee,
                    TimeStart = DateTime.Now.AddHours(3),
                    TimeEnd = DateTime.Now.AddHours(6),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 2, UserId = 1 },
                        new Attendee() { ScheduleId = 1, UserId = 3 },
                        new Attendee() { ScheduleId = 2, UserId = 4 }
                    }
                };

                Schedule schedule_03 = new Schedule
                {
                    Title = "Shopping day",
                    Description = "Shopping therapy",
                    Location = "Attica",
                    CreatorId = 3,
                    Status = ScheduleStatus.Valid,
                    Type = ScheduleType.Shopping,
                    TimeStart = DateTime.Now.AddHours(3),
                    TimeEnd = DateTime.Now.AddHours(6),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 3, UserId = 1 },
                        new Attendee() { ScheduleId = 3, UserId = 4 },
                        new Attendee() { ScheduleId = 3, UserId = 5 }
                    }
                };

                Schedule schedule_04 = new Schedule
                {
                    Title = "Family",
                    Description = "Thanks giving day",
                    Location = "Home",
                    CreatorId = 5,
                    Status = ScheduleStatus.Valid,
                    Type = ScheduleType.Other,
                    TimeStart = DateTime.Now.AddHours(3),
                    TimeEnd = DateTime.Now.AddHours(6),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 4, UserId = 1 },
                        new Attendee() { ScheduleId = 4, UserId = 2 },
                        new Attendee() { ScheduleId = 4, UserId = 5 }
                    }
                };

                Schedule schedule_05 = new Schedule
                {
                    Title = "Friends",
                    Description = "Friends giving day",
                    Location = "Home",
                    CreatorId = 5,
                    Status = ScheduleStatus.Cancelled,
                    Type = ScheduleType.Other,
                    TimeStart = DateTime.Now.AddHours(5),
                    TimeEnd = DateTime.Now.AddHours(7),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 4, UserId = 1 },
                        new Attendee() { ScheduleId = 4, UserId = 2 },
                        new Attendee() { ScheduleId = 4, UserId = 3 },
                        new Attendee() { ScheduleId = 4, UserId = 4 },
                        new Attendee() { ScheduleId = 4, UserId = 5 }
                    }
                };

                Schedule schedule_06 = new Schedule
                {
                    Title = "Meeting with the boss and collegues",
                    Description = "Discuss project planning",
                    Location = "Office",
                    CreatorId = 3,
                    Status = ScheduleStatus.Cancelled,
                    Type = ScheduleType.Other,
                    TimeStart = DateTime.Now.AddHours(22),
                    TimeEnd = DateTime.Now.AddHours(30),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 4, UserId = 1 },
                        new Attendee() { ScheduleId = 4, UserId = 2 },
                        new Attendee() { ScheduleId = 4, UserId = 5 }
                    }
                };

                Schedule schedule_07 = new Schedule
                {
                    Title = "Scenario presentation",
                    Description = "Discuss new movie's scenario",
                    Location = "My special place",
                    CreatorId = 6,
                    Status = ScheduleStatus.Cancelled,
                    Type = ScheduleType.Other,
                    TimeStart = DateTime.Now.AddHours(11),
                    TimeEnd = DateTime.Now.AddHours(13),
                    Attendees = new List<Attendee>
                    {
                        new Attendee() { ScheduleId = 4, UserId = 4 },
                        new Attendee() { ScheduleId = 4, UserId = 2 },
                        new Attendee() { ScheduleId = 4, UserId = 3 }
                    }
                };

                context.Schedule.Add(schedule_01); context.Schedule.Add(schedule_02);
                context.Schedule.Add(schedule_03); context.Schedule.Add(schedule_04);
                context.Schedule.Add(schedule_05); context.Schedule.Add(schedule_06);
            }

            context.SaveChanges();
        }
    }
}
```

**Add Abstract\DomainEnums.cs**

```
namespace NetCoreAspGenericControllers.Abstract
{
    public enum ScheduleType
    {
        Work = 1,
        Coffee = 2,
        Doctor = 3,
        Shopping = 4,
        Other = 5
    }

    public enum ScheduleStatus
    {
        Valid = 1,
        Cancelled = 2
    }
}
```

**Create Migrations and Update Database**

add dependencies to project.json

```
{
    "dependencies": {
        ...
        "Microsoft.EntityFrameworkCore.Design":  "1.1.0"
    },

    "tools": {
        ...
        "Microsoft.EntityFrameworkCore.Tools.DotNet": "1.1.0-preview4-final"
    },
```

```
dotnet ef migrations add First
dotnet ef database update
```

**Run WebApi to call DomainContextInitializer and Seed Data**

Check Database Seeded Data......

----
#### Use more than one Child of GenericCrudController, gives problems in named routes

```
Attribute routes with the same name 'GetById' must have the same template:
Action: 'NetCoreAspGenericControllers.Controllers.DroidController.GetById (NetCoreAspGenericControllers)' - Template: 'api/Droid/{id}'
Action: 'NetCoreAspGenericControllers.Controllers.UserController.GetById (NetCoreAspGenericControllers)' - Template: 'api/User/{id}'
```

We Have Duplicate route names in Attributes ex **GetById** in both

```
[HttpGet("{id}", Name = nameof(GetById))]
```

- [How to resolve System.InvalidOperationException using MVC 6 - Same template](http://stackoverflow.com/questions/30460179/how-to-resolve-system-invalidoperationexception-using-mvc-6-same-template)
- [Generating Route URLs in ASP.NET Core MVC](https://blog.mariusschulz.com/2016/07/21/generating-route-urls-in-asp-net-core-mvc)

One possible solution is using a const to define named route, but it was trick, this is only use to generate urls in MVC, we can skip this step, removing **Name** routes

```
public const string entityType = nameof(E);
...
//[HttpGet("{id}", Name = nameof(GetById))]
[HttpGet("{id}")]
```

After we removed named routes everything works

Create Model\Attendee[Controller|Repository].cs and Repository\Schedule[Controller|Repository].cs ex

```
using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class [ENTITY]Controller : GenericCrudController<[ENTITY], I[ENTITY]Repository>
    {
        public [ENTITY]Controller(I[ENTITY]Repository repository)
            : base(repository)
        {
        }
    }
}
```

```
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Data;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Repository
{
    public class [ENTITY]Repository : EntityBaseRepository<[ENTITY]>, I[ENTITY]Repository
    {
        public [ENTITY]Repository(DomainContext context)
            : base(context)
        { }
    }
}
```

Add repositories to di service

```
// Add Repositories to DI Service Container
services.AddScoped<IScheduleRepository, ScheduleRepository>();
services.AddScoped<IAttendeeRepository, AttendeeRepository>();
```

Run and Test controllers with PostMan

```
Now listening on: http://localhost:5000
...
AttendeeController IsController: True.
DroidController IsController: True.
OrdersFoobar IsController: True.
OrdersFoobarChild IsController: True.
OrdersFoobarController`1 IsController: True.
ScheduleController IsController: True.
UserController IsController: True.
ValuesController IsController: True.
```

![1](/storage/app/media/archive/2017/2017-02/2017-02-23_15_28_06.png)

done we have injected diferent Repositories in generic controllers

----
#### Start Implement Generic CRUD Controller Methods in GenericCrudController.cs

based on great tutorial from [Building REST APIs using ASP.NET Core and Entity Framework Core](https://chsakell.com/2016/06/23/rest-apis-using-asp-net-core-and-entity-framework-core/)

Implementting

- AutoMaper
- Apply ViewModel validations using the FluentValidation Nuget Package
- Apply a global Exception Handler for the API controllers

add dependencies

```
"AutoMapper.Data": "1.0.0-beta1",
"FluentValidation": "6.4.0-rc4"
```

copy 

```
dotnetcore-entityframework-api-master\Scheduler.API\ViewModels 
to ViewModels
dotnetcore-entityframework-api-master\Scheduler.API\Core
to Core
change namespace
```

add to the end of Startup ConfigureServices

```
public void ConfigureServices(IServiceCollection services)
{
    ...
    services.AddSingleton<IDroidRepository, DroidRepository>();

    // Automapper Configuration
    AutoMapperConfiguration.Configure();

    // Enable Cors
    services.AddCors();

    // Add MVC services to the services container
    services.AddMvc()
        .ConfigureApplicationPartManager(manager =>
        {
            // Custom Controller Provider
            manager.FeatureProviders.Add(new CustomControllerFeatureProvider());
        })
        .AddJsonOptions(opts =>
        {
            // Force Camel Case to JSON
            opts.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
        });
}
```

> Note for: **CustomControllerFeatureProvider** and **Force Camel Case to JSON** in **AddMvc()**

fix namespaces and build errors

Now move to implement CRUD controllers

compare **SchedulesController.cs** <> **UsersController.cs** to view diferences

add to **GenericCrudController**

private readonly int page = 1;
private readonly int pageSize = 10;

**Create** and **Put** can be overrided, or use child method for mapper

methods for interface IGenericCrudController

```
[HttpGet]
public IActionResult Get()

[HttpGet("{id}", Name = "GetUser")]
public IActionResult Get(int id)

[HttpGet("{id}/schedules", Name = "GetUserSchedules")]
public IActionResult GetSchedules(int id)

[HttpPost]
public IActionResult Create([FromBody]UserViewModel user)

[HttpPut("{id}")]
public IActionResult Put(int id, [FromBody]UserViewModel user)

[HttpDelete("{id}")]
public IActionResult Delete(int id)
```

create the interface for Generic Controllers based on sample methods

Abstract\IGenericCrudController.cs to use the new Interface ```IGenericCrudController<T>```

```
using Microsoft.AspNetCore.Mvc;

namespace NetCoreAspGenericControllers.Abstract
{
    //T:[Entity]ViewModel
    interface IGenericCrudController<T>
    {
        IActionResult Get();
        IActionResult Get(int id);
        IActionResult Create([FromBody] T user);
        IActionResult Put(int id, [FromBody] T user);
        IActionResult Delete(int id);
    }
}
```

change GenericCrudController.cs

```
namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TRepository, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TRepository : class, IEntityBaseRepository<TEntity>, new()
        where TViewModel : class, IValidatableObject, new()
    {
        private readonly TRepository _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(TRepository repository)
        {
            this._repository = repository;
        }
    ...
```

> Note for inclusion of ```, IGenericCrudController<TViewModel>``` and generic TViewModel for ViewModel

now delete **ALL** old non implemented methods and implement the new interface

![2](/storage/app/media/archive/2017/2017-02/2017-02-23_16_40_06.png)

Done, 

```
namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TRepository, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TRepository : class, IEntityBaseRepository<TEntity>, new()
        where TViewModel : class, IValidatableObject, new()
    {
        private readonly TRepository _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(TRepository repository)
        {
            this._repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            throw new NotImplementedException();
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public IActionResult Create([FromBody] TViewModel user)
        {
            throw new NotImplementedException();
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] TViewModel user)
        {
            throw new NotImplementedException();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
```

dont forget to add [HttpGet], [HttpGet("{id}")], [HttpPost], [HttpPut("{id}")], [HttpDelete("{id}")]

----
#### Create missign ViewMode and Validator STUB for Attendee

NetCoreAspGenericControllers\ViewModels\AttendeeViewModel.cs 

```
namespace NetCoreAspGenericControllers.ViewModels
{
    public class AttendeeViewModel : IValidatableObject
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Avatar { get; set; }
        public string Profession { get; set; }
        public int SchedulesCreated { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new AttendeeViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }
    }
}
```

NetCoreAspGenericControllers\ViewModels\Validations\AttendeeViewModelValidator.cs 

```
namespace NetCoreAspGenericControllers.ViewModels.Validations
{
    public class AttendeeViewModelValidator : AbstractValidator<AttendeeViewModel>
    {
        public AttendeeViewModelValidator()
        {
        }
    }
}
```

fix all generic controllers with new generic **TViewModel** ex AttendeeViewModel

```
namespace NetCoreAspGenericControllers.Controllers 
{
    [Route("api/[controller]")]
    public class AttendeeController : GenericCrudController<Attendee, IAttendeeRepository, AttendeeViewModel>
    ...
```

Now implement the methods ex ```public IActionResult Get(int id)``` to test with diferent model entities :)

----
#### Run and Test It : Interface IController has Controller Problem

Crash in 

```
AttendeeController IsController: True.
OrdersFoobar IsController: True.
OrdersFoobarChild IsController: True.
OrdersFoobarController`1 IsController: True.
ScheduleController IsController: True.
SchedulesController IsController: True.
UserController IsController: True.
UsersController IsController: True.
ValuesController IsController: True.
IGenericCrudController`1 IsController: True.
fail: Microsoft.AspNetCore.Server.Kestrel[13]
      Connection id "0HL2SJ4KG164N": An unhandled exception was thrown by the application.
System.ArgumentNullException: Value cannot be null.
```

```
if (!isController)
{
    isController =
        typeInfo.Name.EndsWith("Controller`1", StringComparison.OrdinalIgnoreCase) ||
        typeInfo.Name.EndsWith("Foobar", StringComparison.OrdinalIgnoreCase);
}
```

Detects ```IGenericCrudController``` has a **Controller** and is a **Interface**

Improves it checking if is a Interface with ```typeInfo.IsInterface```

```
if (!isController)
{
    isController =
        !typeInfo.IsInterface && (
            typeInfo.Name.EndsWith("Controller`1", StringComparison.OrdinalIgnoreCase) ||
            typeInfo.Name.EndsWith("Foobar", StringComparison.OrdinalIgnoreCase)
        )
    ;
}
```

----
#### Run and Test It : Interface IController has Controller Problem

Crash in 

Problem try to use Endpoints 

- http://localhost:5000/api/user
- http://localhost:5000/api/attendee
- http://localhost:5000/api/schedule

```
fail: Microsoft.AspNetCore.Server.Kestrel[13]
      Connection id "0HL2SJMR1U4G1": An unhandled exception was thrown by the application.
System.InvalidOperationException: Unable to resolve service for type 'NetCoreAspGenericControllers.Repository.ScheduleRepository' while attempting to activate 'NetCoreAspGenericControllers.Controllers.ScheduleController'.
   at Microsoft.Extensions.Internal.ActivatorUtilities.GetService(IServiceProvider sp, Type type, Type requiredBy, Boolean isDefaultParameterRequired)
```
   
Unable to resolve service for type 'NetCoreAspGenericControllers.Repository.ScheduleRepository   

Founded The Solution

We must Reorder all project with changes to 

1. Use Inject generic Repositories

```
// Add Repositories to DI Service Container
//services.AddScoped<IScheduleRepository, ScheduleRepository>();
services.AddScoped<IEntityBaseRepository<Schedule>, ScheduleRepository>();
```

2. Change GenericCrudController<TEntity, TRepository, TViewModel> to use only <TEntity, TViewModel>, we now inject Generic Repository has parameter from child class, note for **UNTABBED comments**, this way we dont need **TRepository**

```
namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TRepository, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TRepository : class, IEntityBaseRepository<TEntity>, new()
        where TViewModel : class, IValidatableObject, new()
    {
//private readonly TRepository _repository;
private readonly IEntityBaseRepository<TEntity> _repository;
        private int _page = 1;
        private int _pageSize = 10;

//public GenericCrudController(TRepository repository)
public GenericCrudController(IEntityBaseRepository<TEntity> repository)
        {
            this._repository = repository;
        }
```

Change child controller parameter 

```
public class ScheduleController : GenericCrudController<Schedule, ScheduleRepository, ScheduleViewModel>
{
//public ScheduleController(ScheduleRepository repository)
public ScheduleController(IEntityBaseRepository<Schedule> repository)
        : base(repository)
    {
    }
}
```

![1](/storage/app/media/archive/2017/2017-02/2017-02-24_11_06_03.png)

![2](/storage/app/media/archive/2017/2017-02/2017-02-24_11_06_44.png)

![3](/storage/app/media/archive/2017/2017-02/2017-02-24_11_08_21.png)

----
#### Start make changes for whole project

1. Removing generic <TRepository> from GenericCrudController

```
namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TViewModel : class, IValidatableObject, new()
    {
        private readonly IEntityBaseRepository<TEntity> _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(IEntityBaseRepository<TEntity> repository)
        {
            this._repository = repository;
        }
```        
        
2. Remove TRepository from child controllers and change parameter to IEntityBaseRepository<[Entity]> 

```
public class [Entity]Controller : GenericCrudController<[Entity], [Entity]ViewModel>
{
    public [Entity]Controller(IEntityBaseRepository<[Entity]> repository)
        : base(repository)
    {
    }
}
```

3. Change Startup Services DI Container

```
//services.AddScoped<IScheduleRepository, ScheduleRepository>();
services.AddScoped<IEntityBaseRepository<Schedule>, ScheduleRepository>();

//services.AddScoped<IUserRepository, UserRepository>();
services.AddScoped<IEntityBaseRepository<User>, UserRepository>();

//services.AddScoped<IAttendeeRepository, AttendeeRepository>();
services.AddScoped<IEntityBaseRepository<Attendee>, AttendeeRepository>();
```

**Test GetAll Endpoints**

- http://localhost:5000/api/user
- http://localhost:5000/api/schedule
- http://localhost:5000/api/attendee

![4](/storage/app/media/archive/2017/2017-02/2017-02-24_11_22_02.png)

![5](/storage/app/media/archive/2017/2017-02/2017-02-24_11_23_10.png)

![6](/storage/app/media/archive/2017/2017-02/2017-02-24_11_23_31.png)

----
#### Implement rest of GenericCrudController Controller methods

**Test GetId Endpoints**

- http://localhost:5000/api/user/1
- http://localhost:5000/api/schedule/1
- http://localhost:5000/api/attendee/1

```
fail: Microsoft.AspNetCore.Server.Kestrel[13]
      Connection id "0HL2SL36DJ5L2": An unhandled exception was thrown by the application.
AutoMapper.AutoMapperMappingException: Missing type map configuration or unsupported mapping.

Mapping types:
Attendee -> AttendeeViewModel
NetCoreAspGenericControllers.Model.Attendee -> NetCoreAspGenericControllers.ViewModels.AttendeeViewModel

Destination path:
AttendeeViewModel

Source value:
NetCoreAspGenericControllers.Model.Attendee
```

We must configure DomainToViewModelMappingProfile.cs with [AutoMapper](https://github.com/AutoMapper/AutoMapper/wiki/Getting-started) for Attendee

Let AutoMapper do it automaticcaly with

```
Mapper.CreateMap<Attendee, AttendeeViewModel>();
```

returns

```
{
  "id": 1,
  "name": null,
  "avatar": null,
  "profession": null,
  "schedulesCreated": 0
}
```

![7](/storage/app/media/archive/2017/2017-02/2017-02-24_11_58_34.png)

We must add/create a new Abstract/IViewModel.cs to recognize ids in entitys entity.Id, in generic TViewModel, extending IValidatableObject, this way we can remove IValidatableObject from ViewModels and use IViewModel that implements IValidatableObject

```
namespace NetCoreAspGenericControllers.Abstract
{
    public interface IViewModel : IValidatableObject
    {
        int Id { get; set; }
    }
}
```

Change GenericCrudController where for TViewModel, to use IViewModel, and not IValidatableObject

```
namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
//where TViewModel : class, IValidatableObject, new()
where TViewModel : class, IViewModel, new()
```

Changes in ViewModels

```
//public class UserViewModel : IValidatableObject
public class UserViewModel : IViewModel

//public class ScheduleViewModel : IValidatableObject
public class ScheduleViewModel : IViewModel

//public class AttendeeViewModel : IValidatableObject    
public class AttendeeViewModel : IViewModel
```

Done now we have access to ```entity.Id```, that comes from the new IViewModel

----
#### POST/PUT/DELETE Method, Finallization GENERIC PARTS of Controller

Test Create Method with Body

```
{
  "id": 1,
  "name": "Chris Sakellarios",
  "avatar": "avatar_02.png",
  "profession": "Developer",
  "schedulesCreated": 0
}
```

![8](/storage/app/media/archive/2017/2017-02/2017-02-24_12_23_11.png)

![9](/storage/app/media/archive/2017/2017-02/2017-02-24_12_23_54.png)

```
fail: Microsoft.AspNetCore.Server.Kestrel[13]
      Connection id "0HL2SLVTDOL8U": An unhandled exception was thrown by the application.
Microsoft.EntityFrameworkCore.DbUpdateException: An error occurred while updating the entries. See the inner exception for details. ---> System.Data.SqlClient.SqlException: Cannot insert the value NULL into column 'Name', table 'aspnet-WebApplication-fc1edc2e-8ebf-4398-a70e-6f207fe6df95.dbo.DemoUser'; column does not allow nulls. INSERT fails.
The statement has been terminated.
```

We must implement this line before it works

```
//User _newUser = new User { Name = user.Name, Profession = user.Profession, Avatar = user.Avatar };
```

Delete 

```
Microsoft.EntityFrameworkCore.DbUpdateException: An error occurred while updating the entries. See the inner exception for details. ---> System.Data.SqlClient.SqlException: The DELETE statement conflicted with the REFERENCE constraint "FK_DemoSchedule_DemoUser_CreatorId". The conflict occurred in database "aspnet-WebApplication-fc1edc2e-8ebf-4398-a70e-6f207fe6df95", table "dbo.DemoSchedule", column 'CreatorId'.
```

This is required to implement in outside child controllers methods

final GenericCrudController<TEntity, TViewModel>, missing parts are noted with **TODOs**

```
namespace NetCoreAspGenericControllers.Controllers
{
    [Route("generic-crud-controller")]
    public class GenericCrudController<TEntity, TViewModel> : Controller, IGenericCrudController<TViewModel>
        where TEntity : class, IEntityBase, new()
        where TViewModel : class, IViewModel, new()
    {
        private readonly IEntityBaseRepository<TEntity> _repository;
        private int _page = 1;
        private int _pageSize = 10;

        public GenericCrudController(IEntityBaseRepository<TEntity> repository)
        {
            this._repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var pagination = Request.Headers["Pagination"];

            if (!string.IsNullOrEmpty(pagination))
            {
                string[] vals = pagination.ToString().Split(',');
                int.TryParse(vals[0], out _page);
                int.TryParse(vals[1], out _pageSize);
            }

            int currentPage = _page;
            int currentPageSize = _pageSize;
            var totalUsers = _repository.Count();
            var totalPages = (int)Math.Ceiling((double)totalUsers / _pageSize);

            IEnumerable<TEntity> _entities = _repository
                .GetAll()
// TODO: Custom Override 
//.AllIncluding(u => u.SchedulesCreated) < not generic this method must be overrided
                .OrderBy(u => u.Id)
                .Skip((currentPage - 1) * currentPageSize)
                .Take(currentPageSize)
                .ToList();

            IEnumerable<TViewModel> _usersVM = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TViewModel>>(_entities);

            Response.AddPagination(_page, _pageSize, totalUsers, totalPages);

            return new OkObjectResult(_usersVM);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
// TODO: Custom Override 
//TEntity _entity = default(TEntity);// = _repository.GetSingle(u => u.Id == id, u => u.SchedulesCreated);
            TEntity _entity = _repository.GetSingle(u => u.Id == id);

            if (_entity != null)
            {
                TViewModel _userVM = Mapper.Map<TEntity, TViewModel>(_entity);
                return new OkObjectResult(_userVM);
            }
            else
            {
                return NotFound();
            }
        }

// TODO: Custom Override 
//public IActionResult GetSchedules(int id)
//{
//    throw new NotImplementedException();
//}

        [HttpPost]
        public IActionResult Create([FromBody] TViewModel entity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
// TODO: Custom Override 
//User _newUser = new User { Name = user.Name, Profession = user.Profession, Avatar = user.Avatar };
            TEntity _newEntity = new TEntity();

            _repository.Add(_newEntity);
            _repository.Commit();

            entity = Mapper.Map<TEntity, TViewModel>(_newEntity);

            CreatedAtRouteResult result = CreatedAtRoute("GetUser", new { controller = "Users", id = entity.Id }, entity);

            return result;
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] TViewModel entity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return NotFound();
            }
            else
            {
// TODO: Custom Override 
//_entityDb.Name = entity.Name;
//_entityDb.Profession = entity.Profession;
//_entityDb.Avatar = entity.Avatar;
//_userRepository.Commit();
            }

            entity = Mapper.Map<TEntity, TViewModel>(_entityDb);

            return new NoContentResult();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            TEntity _entityDb = _repository.GetSingle(id);

            if (_entityDb == null)
            {
                return new NotFoundResult();
            }
            else
            {
// TODO: Custom Override 
//IEnumerable<Attendee> _attendees = _attendeeRepository.FindBy(a => a.UserId == id);
//IEnumerable<Schedule> _schedules = _scheduleRepository.FindBy(s => s.CreatorId == id);

//foreach (var attendee in _attendees)
//{
//    _attendeeRepository.Delete(attendee);
//}

//foreach (var schedule in _schedules)
//{
//    _attendeeRepository.DeleteWhere(a => a.ScheduleId == schedule.Id);
//    _scheduleRepository.Delete(schedule);
//}

                _repository.Delete(_entityDb);

                _repository.Commit();

                return new NoContentResult();
            }
        }
    }
}
```
