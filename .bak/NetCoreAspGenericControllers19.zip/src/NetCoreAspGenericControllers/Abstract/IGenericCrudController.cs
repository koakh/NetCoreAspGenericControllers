﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace NetCoreAspGenericControllers.Abstract
{
    //T:[Entity]ViewModel
    interface IGenericCrudController<TEntity, TViewModel>
		where TEntity : class, IEntityBase, new()
		where TViewModel : class, IViewModel, new()
	{
		IActionResult Get();

        IActionResult Get(int id);

        IActionResult Create([FromBody] TViewModel user);

        IActionResult Put(int id, [FromBody] TViewModel user);

        IActionResult Delete(int id);

		//Virtual
		IEnumerable<TEntity> GetEntities(int currentPage, int currentPageSize);

		TEntity GetEntity(int id);

		TEntity CreateEntity(TViewModel viewModel);

		bool UpdateEntity(ref TEntity entity);

		bool DeleteEntity(int id);
	}
}
