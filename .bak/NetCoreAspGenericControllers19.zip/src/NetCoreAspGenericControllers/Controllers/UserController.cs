﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.ViewModels;
using System.Collections.Generic;
using System.Linq;

namespace NetCoreAspGenericControllers.Controllers
{
	[Route("api/[controller]")]
	public class UserController : GenericCrudController<User, UserViewModel>
	{
		private IEntityBaseRepository<User> _repository;

		public UserController(IEntityBaseRepository<User> repository)
			: base(repository)
		{
			_repository = repository;
		}

		// Override base GetEntities method
		public override IEnumerable<User> GetEntities(int currentPage, int currentPageSize)
		{
			IEnumerable<User> entities = _repository
				.AllIncluding(u => u.SchedulesCreated)
				.OrderBy(u => u.Id)
				.Skip((currentPage - 1) * currentPageSize)
				.Take(currentPageSize)
				.ToList();

			return entities;
		}

		// Override base GetEntity method
		public override User GetEntity(int id)
		{
			User entity = _repository
				.GetSingle(
					u => u.Id == id,
					u => u.SchedulesCreated
				);

			return entity;
		}

		// Override base GetEntity method : Must Be Override
		public override User CreateEntity(UserViewModel viewModel)
		{
			User newUser = new User {
				Name = viewModel.Name,
				Profession = viewModel.Profession,
				Avatar = viewModel.Avatar
			};

			return newUser;
		}

		public override bool UpdateEntity(ref User entity)
		{
			return false;
		}

		public override bool DeleteEntity(int id) {
			return false;
		}
	}
}
