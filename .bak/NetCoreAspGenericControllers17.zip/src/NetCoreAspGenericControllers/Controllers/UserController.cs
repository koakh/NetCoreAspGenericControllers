﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.ViewModels;
using System.Collections.Generic;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class UserController : GenericCrudController<User, UserViewModel>
    {
        public UserController(IEntityBaseRepository<User> repository)
            : base(repository)
        {
        }

        public override IEnumerable<User> GetEntity()
        {
            return null;
        }
    }
}
