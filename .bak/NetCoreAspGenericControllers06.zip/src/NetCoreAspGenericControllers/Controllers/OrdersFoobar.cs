using Microsoft.AspNetCore.Mvc;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/orders")]
    public class OrdersFoobar
    {
        [HttpGet]
        public ActionResult Get()
        {

            return new OkResult();
        }
    }
}