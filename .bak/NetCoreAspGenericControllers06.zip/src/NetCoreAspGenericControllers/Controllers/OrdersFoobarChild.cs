﻿using Microsoft.AspNetCore.Mvc;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/simpleorder")]
    public class OrdersFoobarChild : OrdersFoobarController<SimpleOrder>
    {
    }
}