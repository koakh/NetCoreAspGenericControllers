﻿using NetCoreAspGenericControllers.Model;

namespace DomainData.Abstract
{
    public interface IUserRepository : IEntityBaseRepository<User> { }
    public interface IDroidRepository : IEntityBaseRepository<Droid> { }
}
