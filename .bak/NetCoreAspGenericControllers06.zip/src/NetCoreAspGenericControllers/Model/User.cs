﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace NetCoreAspGenericControllers.Model
{
    public class User : EntityBase
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Name { get; set; }
        public string Avatar { get; set; }
        public string Profession { get; set; }
    }
}
