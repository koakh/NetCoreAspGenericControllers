﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class DroidGenericCrudController : GenericCrudController<Droid, IDroidRepository>
    {
        public DroidGenericCrudController(IDroidRepository repository) 
            : base(repository)
        {
        }
    }
}
