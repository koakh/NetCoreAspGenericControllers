﻿using DomainModel.Entities;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Data;

namespace NetCoreAspGenericControllers.Repository
{
    public class UserRepository : EntityBaseRepository<User>, IUserRepository
    {
        public UserRepository(DomainContext context)
            : base(context)
        { }
    }
}
