﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using NetCoreAspGenericControllers.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Controllers
{
    [Route("api/[controller]")]
    public class DroidGenericCrudController : GenericCrudController<Droid>
    {
        public DroidGenericCrudController(IDroidRepository repository) 
            : base(repository)
        {
        }
    }
}
