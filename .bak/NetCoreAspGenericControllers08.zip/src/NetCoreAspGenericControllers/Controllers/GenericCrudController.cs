﻿using Microsoft.AspNetCore.Mvc;
using NetCoreAspGenericControllers.Abstract;
using NetCoreAspGenericControllers.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetCoreAspGenericControllers.Controllers
{
    // T1 Entity
    // T2 IRepository
    [Route("generic-crud-controller")]
    public class GenericCrudController<T> : Controller
        where T : IEntityBase
    {
        readonly IEntityBaseRepository<Droid> repository;

        public GenericCrudController(IEntityBaseRepository<Droid> repository)
        {
             this.repository = repository;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            throw new NotImplementedException();
        }

        [HttpGet("{id}", Name = nameof(GetById))]
        public IActionResult GetById(int id)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        public IActionResult Create([FromBody] T entity)
        {
            throw new NotImplementedException();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            throw new NotImplementedException();
        }

        [HttpPut]
        public IActionResult Update([FromBody] T entity)
        {
            throw new NotImplementedException();
        }
    }
}
